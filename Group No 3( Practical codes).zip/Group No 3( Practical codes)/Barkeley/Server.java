import java.io.*;
import java.net.*;
import java.util.*;

public class Server {
    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = null;
        Socket clientSocket = null;
        PrintWriter out = null;
        BufferedReader in = null;

        try {
            
            serverSocket = new ServerSocket(4444);
        } catch (IOException e) {
            System.err.println("Could not listen on port: 4444.");
            System.exit(1);
        }

      
        while (true) {
            try {
                clientSocket = serverSocket.accept();
                System.out.println("Accepted connection from " + clientSocket.getInetAddress().getHostName());

                out = new PrintWriter(clientSocket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

                Thread t = new ServerThread(clientSocket, out, in);
                t.start();
            } catch (IOException e) {
                System.err.println("Error handling client connection.");
            }
        }
    }
}

class ServerThread extends Thread {
    private Socket clientSocket;
    private PrintWriter out;
    private BufferedReader in;

    public ServerThread(Socket socket, PrintWriter out, BufferedReader in) {
        this.clientSocket = socket;
        this.out = out;
        this.in = in;
    }

    public void run() {
        try {

            long clientTime = Long.parseLong(in.readLine());
            System.out.println("Received time from " + clientSocket.getInetAddress().getHostName() + ": " + clientTime);

     
            long serverTime = System.currentTimeMillis();
            System.out.println("Server time: " + serverTime);

            long offset = serverTime - clientTime;
            System.out.println("Offset: " + offset);

            out.println(offset);

            in.close();
            out.close();
            clientSocket.close();
        } catch (IOException e) {
            System.err.println("Error handling client connection.");
        }
    }
}
