import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class ConcatServer extends UnicastRemoteObject implements ConcatInterface {

    public ConcatServer() throws RemoteException {
        super();
    }

    public String concat(String s1, String s2) throws RemoteException {
        return s1 + s2;
    }

    public static void main(String[] args) {
        try {
            ConcatServer server = new ConcatServer();
            Registry registry = LocateRegistry.createRegistry(1099);
            registry.rebind("ConcatServer", server);
            System.out.println("Server is running...");
        } catch (Exception e) {
            System.err.println("Server exception: " + e.toString());
            e.printStackTrace();
        }
    }
}
