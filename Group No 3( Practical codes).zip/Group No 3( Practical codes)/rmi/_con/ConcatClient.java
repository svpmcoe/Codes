import java.util.Scanner;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class ConcatClient {
    public static void main(String[] args) {
        try {
            Registry registry = LocateRegistry.getRegistry("localhost", 1099);
            ConcatInterface concat = (ConcatInterface) registry.lookup("ConcatServer");

            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter the first string: ");
            String s1 = scanner.nextLine();
            System.out.print("Enter the second string: ");
            String s2 = scanner.nextLine();

            String result = concat.concat(s1, s2);
            System.out.println("Result: " + result);
        } catch (Exception e) {
            System.err.println("Client exception: " + e.toString());
            e.printStackTrace();
        }
    }
}
