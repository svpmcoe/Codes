import java.rmi.Naming;

public class FactorialClient {
    public static void main(String args[]) {
        try {
            // Get a reference to the remote object from the registry
            FactorialInterface obj = (FactorialInterface) Naming.lookup("//localhost/FactorialService");

            // Get the input value from the user
            int n = Integer.parseInt(args[0]);

            // Call the remote method to compute the factorial
            int result = obj.factorial(n);

            // Print the result
            System.out.println(n + "! = " + result);
        } catch (Exception e) {
            System.err.println("FactorialClient exception: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
