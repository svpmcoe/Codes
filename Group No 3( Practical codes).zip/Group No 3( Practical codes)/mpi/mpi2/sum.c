#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char** argv) {
  int rank, size, i, n;
  int sum = 0, local_sum = 0;
  int* array;

  if (argc != 2) {
    fprintf(stderr, "Usage: %s <n>\n", argv[0]);
    exit(1);
  }

  // Get the number of elements from the command-line argument
  n = atoi(argv[1]);

  // Initialize MPI
  MPI_Init(&argc, &argv);

  // Get the rank of the current process
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);

  // Get the total number of processes
  MPI_Comm_size(MPI_COMM_WORLD, &size);

  // Allocate memory for the array
  array = (int*) malloc(n * sizeof(int));

  // Initialize array with random values
  srand(rank + 1);
  for (i = 0; i < n; i++) {
    array[i] = rand() % 100;
  }

  // Calculate the sum of the local portion of the array
  for (i = rank * (n / size); i < (rank + 1) * (n / size); i++) {
    local_sum += array[i];
  }

  // Display the intermediate sums calculated by each process
  printf("Process %d: Local Sum = %d\n", rank, local_sum);
  fflush(stdout);

  // Gather the local sums from all processes to display the detailed output calculation
  int* gathered_sums = NULL;
  if (rank == 0) {
    gathered_sums = (int*) malloc(size * sizeof(int));
  }
  MPI_Gather(&local_sum, 1, MPI_INT, gathered_sums, 1, MPI_INT, 0, MPI_COMM_WORLD);

  // Display the detailed output calculation information on rank 0
  if (rank == 0) {
    printf("Detailed Output Calculation:\n");
    for (int i = 0; i < size; i++) {
      printf("Process %d calculated sum = %d\n", i, gathered_sums[i]);
    }
    printf("\n");
    fflush(stdout);
    free(gathered_sums);
  }

  // Reduce the local sums from all processes to obtain the final sum
  MPI_Allreduce(&local_sum, &sum, 1, MPI_INT, MPI_SUM, MPI_COMM_WORLD);

  // Print the final sum calculated by process 0
  if (rank == 0) {
    printf("Final sum: %d\n", sum);
    fflush(stdout);
  }

  // Free memory for the array
  free(array);

  // Finalize MPI
  MPI_Finalize();

  return 0;
}
